# Space Betrayal continuity

This is a separate game from In the Dojo. Do not modify that repository.
Read README.md and Docs/STATUS.md before continuing.

Approved target: PC and Android, first person, realistic astronauts and frightening original aliens, classic social deduction only, 12–40 participants, 1–5 traitors, 11 roles, 5 maps. The user explicitly added Hunter as a CREW member spawning with a Winchester and able to eliminate ONLY traitors. Crew targets must always survive, including if a Mimetic copied their identity. Prototype tuning is 3 cartridges, 25m range, 3s between shots; these are implementation defaults, not user-specified balance values.

Current deliverable: 0.2.0 local bot prototype on OMEGA-9, with original procedural placeholder geometry and audio, including an original low-poly lever-action rifle. It does NOT have online networking or final realistic artwork. Do not present bots as human multiplayer, PC touch simulation as Android hardware validation, or accelerated simulations as GPU performance evidence.

Keep PC and Android input working, secret identities, tasks, body reporting, voting/skip/ties, proximity and visibility checks, cooldowns, protection, reactor repair and win conditions. Keep the tests in tests/ and test-only flags clearly separated from normal gameplay.

Godot 4.7.2 Compatibility renderer. Shader disk cache is disabled because cached OpenGL shader loading crashed in the available Intel driver; repeated fresh shader runs succeeded. Use local tool/cache/log directories. Do not alter OS security or installed engines.

Only use assets with appropriate free licenses and preserve their notices. Current authored scene and audio use no downloaded third-party art. Godot runtime remains under its own license and third-party notices.
