@echo off
setlocal
if not exist "%~dp0Data" mkdir "%~dp0Data"
set "APPDATA=%~dp0Data"
set "LOCALAPPDATA=%~dp0Data"
start "" "%~dp0SpaceBetrayal.exe" --log-file "%~dp0Data\play.log"
